package pageobjects;

public class DashboardPage {

}
