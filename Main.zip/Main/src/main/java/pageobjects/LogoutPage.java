package pageobjects;

public class LogoutPage {

}
