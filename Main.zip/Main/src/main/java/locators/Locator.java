package locators;

import org.openqa.selenium.By;

public class Locator {

	public static class loginLocator {
		// Locator for login page
		public static final By Usernamefield = By.id("username");
		public static final By Passwordfield = By.id("password");
		public static final By loginbtn = By.id("login");

	}
}
