package utils;

import org.openqa.selenium.WebDriver;
import utils.browserType.browser;

public class WbeDriverFactory {
    private static final ThreadLocal<WebDriver> driverThread = new ThreadLocal<>();

    public static WebDriver getDriver(browser browser) {
        if (driverThread.get() == null) {
            WebDriver driver = WebDriverManagerUtil.createDriver(browser);
            if (driver == null) {
                throw new RuntimeException("Failed to create driver for browser: " + browser);
            }
            driverThread.set(driver);
        }
        return driverThread.get();
    }

    public static void quit() {
        WebDriver driver = driverThread.get();
        if (driver != null) {
            try {
                driver.quit();
            } catch (Exception e) {
                System.err.println("Error while quitting driver: " + e.getMessage());
            } finally {
                driverThread.remove();
            }
        }
    }
}