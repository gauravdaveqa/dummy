package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.safari.SafariDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.browserType.browser;

public class WebDriverManagerUtil {

    public static WebDriver createDriver(browser browser) {
        WebDriver driver = null;

        try {
            switch (browser) {
                case CHROME:
                    // Let WebDriverManager automatically match the Chrome browser version
                    WebDriverManager.chromedriver().clearDriverCache().setup();
                    
                    ChromeOptions chromeOptions = new ChromeOptions();
                    chromeOptions.addArguments("--remote-allow-origins=*");
                    chromeOptions.addArguments("--disable-dev-shm-usage");
                    chromeOptions.addArguments("--no-sandbox");
                    chromeOptions.addArguments("--disable-gpu");
                    chromeOptions.addArguments("--window-size=1920,1080");
                    chromeOptions.setHeadless(false);
                    
                    driver = new ChromeDriver(chromeOptions);
                    break;

                case FIREFOX:
                    WebDriverManager.firefoxdriver().setup();
                    FirefoxOptions firefoxOptions = new FirefoxOptions();
                    firefoxOptions.addArguments("--width=1920");
                    firefoxOptions.addArguments("--height=1080");
                    firefoxOptions.setHeadless(false);
                    
                    driver = new FirefoxDriver(firefoxOptions);
                    break;

                case EDGE:
                    WebDriverManager.edgedriver().setup();
                    driver = new EdgeDriver();
                    break;

                case SAFARI:
                    WebDriverManager.safaridriver().setup();
                    driver = new SafariDriver();
                    break;

                default:
                    throw new IllegalArgumentException("Unsupported browser: " + browser);
            }

            if (driver != null) {
                driver.manage().window().maximize();
                System.out.println("Successfully launched: " + browser);
            } else {
                throw new RuntimeException("Driver initialization failed for: " + browser);
            }

        } catch (Exception e) {
            System.err.println("ERROR initializing WebDriver for " + browser + ": " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("WebDriver initialization failed", e);
        }

        return driver;
    }
}