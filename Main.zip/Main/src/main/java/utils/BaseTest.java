package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import utils.browserType.browser;

public class BaseTest {
    protected static WebDriver driver;
    protected static WebDriverWait wait;

    public static void setup(browser browser) {
        try {
            driver = WbeDriverFactory.getDriver(browser);
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            wait = new WebDriverWait(driver, Duration.ofSeconds(120));
            driver.get("http://44.227.114.189:8708/auth/user/sign-in");
        } catch (Exception e) {
            System.err.println("Failed to initialize browser: " + browser);
            e.printStackTrace();
            throw new RuntimeException("Browser setup failed", e);
        }
    }

    public static void quit() {
        try {
            WbeDriverFactory.quit();
        } catch (Exception e) {
            System.err.println("Error quitting browser");
            e.printStackTrace();
        }
    }
}