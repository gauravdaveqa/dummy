package utils;

public class browserType {
	public enum browser {
		CHROME, FIREFOX, EDGE, SAFARI;
	}
}