package Hooks;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import utils.BaseTest;
import utils.browserType.browser;

public class hook extends BaseTest {

    @BeforeClass
    @Parameters({"browser"})
    public void setupTest(String browserName) {
        browser browserType = browser.valueOf(browserName.toUpperCase());
        setup(browserType);
    }

    @Test
    public void verifyPageTitle() {
        String pageTitle = driver.getTitle();
        System.out.println("Verified Page Title: " + pageTitle);
        Assert.assertEquals(pageTitle, "Oyraa Admin", "Page title verification failed");
    }

    @AfterClass
    public void teardownTest() {
        quit();
    }
}